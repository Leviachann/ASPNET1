﻿using Homework1.Entities;
using Homework1.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace Homework1.Controllers
{
    public class HomeController : Controller
    {

        public IActionResult Index()
        {
            List<Fastfood> fastfoods = new List<Fastfood> {
                new Fastfood
                {
                    Id = 1,
                    Name = "Cheese Burger",
                    Description="Who doesnt love cheese honestly",
                    Price=5.99
                },
                 new Fastfood
                {
                    Id = 2,
                    Name = "French Fries",
                    Description="Freezed potatoes cooked weird",
                    Price=3.99
                },
                 new Fastfood
                {
                    Id = 3,
                    Name = "Cola 1L",
                    Description="Prices get higher by time",
                    Price=4.99
                }

            };

            List<Hotmeal> hotmeals = new List<Hotmeal> {
                new Hotmeal
                {
                    Id = 1,
                    Name = "Bozbash",
                    Description="Meat potato soup.",
                    Price=29.99
                },
                 new Hotmeal
                {
                    Id = 2,
                    Name = "Plov",
                    Description="Plov is Plov no questions asked",
                    Price=19.99
                },
                 new Hotmeal
                {
                    Id = 3,
                    Name = "Steak",
                    Description="Just fancily cooked meat",
                    Price=39.99
                }

            };

            List<Drink> drinks = new List<Drink> {
                new Drink
                {
                    Id = 1,
                    Name = "Mocha",
                    Description="Green Drink with a bitter taste.",
                    Price=9.99
                },
                 new Drink
                {
                    Id = 2,
                    Name = "Peachy Ice Tea",
                    Description="Very cold and sweet",
                    Price=9.99
                },
                 new Drink
                {
                    Id = 3,
                    Name = "Water",
                    Description="plain water",
                    Price=9.99
                }

            };
            var ViewModel = new MenuViewModel
            {
                Drinks = drinks,
                Fastfoods = fastfoods,
                Hotmeals = hotmeals,
            };
            return View(ViewModel);
        }
        public ViewResult Drinks()
        {
            List<Drink> drinks = new List<Drink> {
                new Drink
                {
                    Id = 1,
                    Name = "Mocha",
                    Description="Green Drink with a bitter taste.",
                    Price=9.99
                },
                 new Drink
                {
                    Id = 2,
                    Name = "Peachy Ice Tea",
                    Description="Very cold and sweet",
                    Price=9.99
                },
                 new Drink
                {
                    Id = 3,
                    Name = "Plain water",
                    Description="plain water",
                    Price=9.99
                }

            };
            return View(drinks);
        }
        public ViewResult Hotmeals()
        {
            List<Hotmeal> hotmeals = new List<Hotmeal> {
                new Hotmeal
                {
                    Id = 1,
                    Name = "Bozbash",
                    Description="Meat potato soup.",
                    Price=29.99
                },
                 new Hotmeal
                {
                    Id = 2,
                    Name = "Plov",
                    Description="Plov is Plov no questions asked",
                    Price=19.99
                },
                 new Hotmeal
                {
                    Id = 3,
                    Name = "Steak",
                    Description="Just fancily cooked meat",
                    Price=39.99
                }

            };
            return View(hotmeals);
        }
        public ViewResult Fastfoods()
        {
            List<Fastfood> fastfoods = new List<Fastfood> {
                new Fastfood
                {
                    Id = 1,
                    Name = "Cheese Burger",
                    Description="Who doesnt love cheese honestly",
                    Price=5.99
                },
                 new Fastfood
                {
                    Id = 2,
                    Name = "French Fries",
                    Description="Freezed potatoes cooked weird",
                    Price=3.99
                },
                 new Fastfood
                {
                    Id = 3,
                    Name = "Cola 1L",
                    Description="Prices get higher by time",
                    Price=4.99
                }

            };
            return View(fastfoods);
        }
    }
}