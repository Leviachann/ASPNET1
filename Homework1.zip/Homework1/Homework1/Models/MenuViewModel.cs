﻿using Homework1.Entities;

namespace Homework1.Models
{
    public class MenuViewModel
    {
        public List<Hotmeal> Hotmeals { get; set; }
        public List<Fastfood> Fastfoods { get; set; }
        public List<Drink> Drinks { get; set; }

    }
}
